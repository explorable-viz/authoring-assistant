#!/bin/bash
# Generally ollama runs on the 11434 port.
set -xe
ollama serve &
