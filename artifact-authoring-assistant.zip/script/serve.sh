#!/bin/bash

npx http-serve dist/$1
