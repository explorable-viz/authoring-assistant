package authoringassistant;

import authoringassistant.paragraph.Literal;

public record LiteralParts(Literal beforeTag, Literal tag, Literal afterTag) {}
